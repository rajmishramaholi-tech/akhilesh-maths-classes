# Akhilesh Maths Classes — Android APK project

This project wraps the dark-theme offline HTML app in an Android WebView.

## Build output
The GitHub Actions workflow builds a debug APK at:
`app/build/outputs/apk/debug/app-debug.apk`

## Build using GitHub Actions
1. Create a new GitHub repository (ask a parent/teacher to help manage the account).
2. Upload the contents of this ZIP to the repository.
3. Open the repository's **Actions** tab.
4. Run **Build Android APK** (or push a commit to start it automatically).
5. Download the `Akhilesh-Maths-Classes-debug-apk` artifact from the completed workflow.
6. Only install APKs built from your own repository; do not share real student records in this demo.

## Important
- This is an offline demo wrapper. It does not add Firebase, secure user accounts, or cloud sync.
- The HTML app stores demo data in WebView local storage on that device.
- A debug APK is for testing, not a Play Store release.
